import Invite from "../models/Invite.js";
import User from "../models/User.js";
import { signToken } from "../utils/jwt.js";
import { saveOtp, verifyOtp } from "../utils/otpStore.js";
import { generateOtp } from "../utils/generateOtp.js";
import { auditLogger } from "../utils/auditLogger.js"; // ✅ ADDED

/**
 * SEND OTP
 * Allowed only for:
 * 1. Super Admin
 * 2. Valid Admin Invite
 */
export const sendOtp = async (req, res) => {
  try {
    console.log("Body:", req.body);
    const { mobile } = req.body;

    if (!mobile) {
      return res.status(400).json({ message: "Mobile number required" });
    }

    const superAdmin = await User.findOne({
      mobile,
      roles: "SUPER_ADMIN"
    });

    const adminInvite = await Invite.findOne({
      mobile,
      role: "ADMIN",
      expiresAt: { $gt: new Date() }
    });

    if (!superAdmin && !adminInvite) {
      return res.status(403).json({
        message: "Not allowed to request OTP"
      });
    }

    const otp = generateOtp();
    saveOtp(mobile, otp);

    console.log(`OTP for ${mobile} is ${otp}`);
    console.log("OTP for", mobile, ":", otp);

    res.json({ message: "OTP sent successfully" });
  } catch (err) {
    res.status(500).json({ message: "Failed to send OTP" });
  }
};

export const sendOtpUser = async (req, res) => {
  try {
    const { mobile } = req.body;

    if (!mobile) {
      return res.status(400).json({
        message: "Mobile number required"
      });
    }

    // 1️⃣ check user
    const user = await User.findOne({ mobile });

    // ❌ super admin blocked
    if (user?.roles.includes("SUPER_ADMIN")) {
      return res.status(403).json({
        message: "Super admin login not allowed in mobile app"
      });
    }

    // 2️⃣ check invite (resident or guard)
    const invite = await Invite.findOne({
      mobile,
      role: { $in: ["ADMIN", "RESIDENT", "GUARD"] },
      status: "PENDING",
      expiresAt: { $gt: new Date() }
    });

    if (!user && !invite) {
      return res.status(403).json({
        message: "You are not invited to any society"
      });
    }

    // ✅ send OTP
    const otp = generateOtp();
    saveOtp(mobile, otp);

    console.log(`USER OTP for ${mobile}: ${otp}`);

    res.json({
      message: "OTP sent successfully",
      role: invite?.role || user.roles[0]
    });
  } catch (err) {
    console.error("SEND USER OTP ERROR:", err);
    res.status(500).json({
      message: "Failed to send OTP"
    });
  }
};

/**
 * VERIFY OTP — SUPER ADMIN LOGIN
 */
export const verifyOtpLogin = async (req, res) => {
  try {
    const { mobile, otp } = req.body;

    if (!verifyOtp(mobile, otp)) {
      return res.status(401).json({ message: "Invalid OTP" });
    }

    const user = await User.findOne({
      mobile,
      roles: "SUPER_ADMIN"
    });

    if (!user) {
      return res.status(404).json({ message: "Super Admin not found" });
    }

    if (user.status === "BLOCKED") {
      return res.status(403).json({
        message: "Account is blocked"
      });
    }

    const token = signToken({
      userId: user._id,
      role: "SUPER_ADMIN"
    });

    res.json({ token });
  } catch (err) {
    res.status(500).json({ message: "Login failed" });
  }
};

/**
 * VERIFY OTP — ADMIN LOGIN / SIGNUP
 * 🔐 AUDIT LOG ENABLED HERE ONLY
 */
export const verifyUserLogin = async (req, res) => {
  try {
    const { mobile, otp } = req.body;

    // 1️⃣ Verify OTP
    if (!verifyOtp(mobile, otp)) {
      return res.status(401).json({ message: "Invalid OTP" });
    }

    // 2️⃣ Existing user login
    let user = await User.findOne({ mobile });

    if (user) {
      if (user.status === "BLOCKED") {
        return res.status(403).json({ message: "Account is blocked" });
      }

      // ✅ OPTION A: DO NOT reduce roles
      const token = signToken({
        userId: user._id,
        roles: user.roles,          // ✅ ALL ROLES
        societyId: user.societyId
      });

      return res.json({
        token,
        roles: user.roles,          // frontend can decide mode
        societyId: user.societyId
      });
    }

    // 3️⃣ No user → check invite
    const invite = await Invite.findOne({
      mobile,
      role: { $in: ["ADMIN", "RESIDENT", "GUARD"] },
      status: "PENDING",
      expiresAt: { $gt: new Date() }
    });

    if (!invite) {
      return res.status(403).json({
        message: "You are not invited to any society"
      });
    }

    // 4️⃣ Create user based on invite
    const roles = [invite.role];

    // admin is also resident
    if (invite.role === "ADMIN") {
      roles.push("RESIDENT");
    }

    user = await User.create({
      name: invite.name,
      mobile,
      roles,
      flatNo: invite.flatNo,
      societyId: invite.societyId,
      invitedBy: invite.invitedBy,
      status: "ACTIVE"
    });

    // 5️⃣ mark invite used
    invite.status = "USED";
    await invite.save();

    // ✅ audit log
    await auditLogger({
      req,
      action: "USER_VERIFIED",
      targetType: "USER",
      targetId: user._id,
      societyId: user.societyId,
      description: `${invite.role} verified via OTP: ${user.name} (${user.mobile})`
    });

    // ✅ OPTION A: token with ALL roles
    const token = signToken({
      userId: user._id,
      roles: user.roles,
      societyId: user.societyId
    });

    return res.json({
      token,
      roles: user.roles,
      societyId: user.societyId
    });

  } catch (err) {
    console.error("VERIFY USER LOGIN ERROR:", err);
    res.status(500).json({ message: "Login failed" });
  }
};



