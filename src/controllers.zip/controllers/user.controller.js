import User from "../models/User.js";
import VisitorLog from "../models/VisitorLog.js";

export const getUsersByRole = async (req, res) => {
  const { role } = req.query;

  if (!role) {
    return res.status(400).json({ message: "Role is required" });
  }

  const users = await User.find({ roles: { $in: [role] } })
    .populate("societyId", "name city _id")
    .select("name mobile roles status societyId createdAt")
    .sort({ createdAt: -1 });

  res.json(users);
};

export const getMyProfile = async (req, res) => {
  try {
    const userId = req.user.userId;

    const user = await User.findById(userId)
      .populate("societyId", "name")
      .populate("invitedBy", "name mobile")
      .select("-__v");

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found"
      });
    }

    return res.status(200).json({
      success: true,
      user: {
        _id: user._id,
        name: user.name,
        mobile: user.mobile,
        roles: user.roles,
        flatNo: user.flatNo,
        status: user.status,
        society: user.societyId,
        invitedBy: user.invitedBy,
        createdAt: user.createdAt
      }
    });

  } catch (error) {
    console.error("Profile Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch profile"
    });
  }
};


export const getResidentVisitorHistory = async (req, res) => {
  try {
    const residentId = req.user.userId;
    const societyId = req.user.societyId;

    if (!residentId || !societyId) {
      return res.status(403).json({
        success: false,
        message: "Resident not linked to society"
      });
    }

    const visitors = await VisitorLog.find({
      residentId: residentId,
      societyId: societyId
    })
      .populate("guardId", "name")
      .sort({ createdAt: -1 });

    return res.status(200).json({
      success: true,
      totalVisitors: visitors.length,
      visitors
    });

  } catch (error) {
    console.error("Resident Visitor History Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to fetch visitor history"
    });
  }
};
