import Invite from "../models/Invite.js";
import Society from "../models/Society.js";
import { auditLogger } from "../utils/auditLogger.js"; // ✅ ADDED

const INVITE_EXPIRY_HOURS = 24;

/**
 * CREATE ADMIN INVITE
 */
/**
 * CREATE ADMIN INVITE
 * ADMIN = SECRETARY = RESIDENT
 * So admin must have flatNo
 */
export const inviteAdmin = async (req, res) => {
  const { name, mobile, societyId, flatNo } = req.body;

  // ✅ flatNo required because admin lives in society
  if (!name || !mobile || !societyId || !flatNo) {
    return res.status(400).json({
      message: "Name, mobile, societyId and flat number are required"
    });
  }

  const society = await Society.findById(societyId);
  if (!society) {
    return res.status(404).json({ message: "Society not found" });
  }

  // ❌ flat already assigned to someone else
  const flatExists = await Invite.findOne({
    societyId,
    flatNo,
    status: { $in: ["PENDING", "USED"] }
  });

  if (flatExists) {
    return res.status(409).json({
      message: `Flat ${flatNo} already assigned`
    });
  }

  const expiresAt = new Date(
    Date.now() + INVITE_EXPIRY_HOURS * 60 * 60 * 1000
  );

  // 🔍 check existing admin invite
  let invite = await Invite.findOne({
    mobile,
    role: "ADMIN",
    societyId
  });

  // ❌ already onboarded
  if (invite && invite.status === "USED") {
    return res.status(409).json({
      message: "Admin already onboarded with this number"
    });
  }

  // 🔁 update existing invite
  if (invite) {
    invite.name = name;
    invite.flatNo = flatNo; // ✅ assign flat
    invite.status = "PENDING";
    invite.expiresAt = expiresAt;
    invite.invitedBy = req.user.userId;

    await invite.save();

    await auditLogger({
      req,
      action: "UPDATE_ADMIN_INVITE",
      targetType: "INVITE",
      targetId: invite._id,
      societyId,
      description: `Admin invite updated | Flat ${flatNo}`
    });

    return res.json({
      message: "Existing admin invite updated",
      invite
    });
  }

  // 🆕 create new admin invite
  invite = await Invite.create({
    name,
    mobile,
    flatNo,          // ✅ VERY IMPORTANT
    role: "ADMIN",
    societyId,
    invitedBy: req.user.userId,
    expiresAt
  });

  await auditLogger({
    req,
    action: "CREATE_ADMIN_INVITE",
    targetType: "INVITE",
    targetId: invite._id,
    societyId,
    description: `Admin invited | Flat ${flatNo}`
  });

  res.status(201).json({
    message: "Admin invite created",
    invite
  });
};

/**
 * GET ALL INVITES
 * 🚫 NO AUDIT LOG (READ-ONLY)
 */
export const getAllInvites = async (req, res) => {
  const invites = await Invite.find()
    .populate("societyId", "name city")
    .sort({ createdAt: -1 });

  res.json(invites);
};

/**
 * RESEND INVITE
 */
export const resendInvite = async (req, res) => {
  const { id } = req.params;

  const invite = await Invite.findById(id);
  if (!invite || invite.status !== "PENDING") {
    return res.status(400).json({ message: "Invite not valid" });
  }

  invite.expiresAt = new Date(
    Date.now() + INVITE_EXPIRY_HOURS * 60 * 60 * 1000
  );
  await invite.save();

  // ✅ AUDIT LOG — RESEND
  await auditLogger({
    req,
    action: "RESEND_ADMIN_INVITE",
    targetType: "INVITE",
    targetId: invite._id,
    societyId: invite.societyId,
    description: `Admin invite resent for ${invite.name} (${invite.mobile})`
  });

  res.json({ message: "Invite resent" });
};

/**
 * CANCEL INVITE
 */
export const cancelInvite = async (req, res) => {
  const { id } = req.params;

  const invite = await Invite.findById(id);
  if (!invite || invite.status !== "PENDING") {
    return res.status(400).json({ message: "Invite not valid" });
  }

  invite.status = "EXPIRED";
  await invite.save();

  // ✅ AUDIT LOG — CANCEL
  await auditLogger({
    req,
    action: "CANCEL_ADMIN_INVITE",
    targetType: "INVITE",
    targetId: invite._id,
    societyId: invite.societyId,
    description: `Admin invite cancelled for ${invite.name} (${invite.mobile})`
  });

  res.json({ message: "Invite cancelled" });
};

import User from "../models/User.js";

export const inviteResident = async (req, res) => {
  try {
    const { name, mobile, flatNo } = req.body;

    // ✅ basic validation
    if (!name || !mobile || !flatNo) {
      return res.status(400).json({
        message: "Name, mobile and flat number are required"
      });
    }

    // 🔐 get admin
    const admin = await User.findById(req.user.userId);

    if (!admin || !admin.societyId) {
      return res.status(403).json({
        message: "Admin society not found"
      });
    }

    // ❌ flat already assigned
    const flatExists = await Invite.findOne({
      societyId: admin.societyId,
      flatNo,
      status: { $in: ["PENDING", "USED"] }
    });

    if (flatExists) {
      return res.status(409).json({
        message: `Flat ${flatNo} already assigned`
      });
    }

    // ❌ number already used by admin or guard
    const existingUser = await User.findOne({ mobile });

    if (existingUser?.roles.includes("ADMIN")) {
      return res.status(400).json({
        message: "This number belongs to an admin"
      });
    }

    if (existingUser?.roles.includes("GUARD")) {
      return res.status(400).json({
        message: "This number belongs to a guard"
      });
    }

    const expiresAt = new Date(
      Date.now() + INVITE_EXPIRY_HOURS * 60 * 60 * 1000
    );

    // 🔁 check existing resident invite
    let invite = await Invite.findOne({
      mobile,
      role: "RESIDENT",
      societyId: admin.societyId
    });

    // ❌ already onboarded
    if (invite?.status === "USED") {
      return res.status(409).json({
        message: "Resident already onboarded"
      });
    }

    // ❌ already invited
    if (invite?.status === "PENDING") {
      return res.status(409).json({
        message: `Invite already sent to ${mobile}`
      });
    }

    // 🔁 update expired invite
    if (invite) {
      invite.name = name;
      invite.flatNo = flatNo;
      invite.status = "PENDING";
      invite.expiresAt = expiresAt;
      invite.invitedBy = admin._id;
      await invite.save();
    }
    // 🆕 create invite
    else {
      invite = await Invite.create({
        name,
        mobile,
        flatNo,
        role: "RESIDENT",
        societyId: admin.societyId,
        invitedBy: admin._id,
        expiresAt
      });
    }

    // ✅ AUDIT LOG
    await auditLogger({
      req,
      action: "INVITE_RESIDENT",
      targetType: "INVITE",
      targetId: invite._id,
      societyId: admin.societyId,
      description: `Resident invited: ${name} (${mobile}) | Flat ${flatNo}`
    });

    res.json({
      message: "Resident invite sent successfully",
      invite
    });

  } catch (err) {
    console.error("INVITE RESIDENT ERROR:", err);
    res.status(500).json({
      message: "Failed to invite resident"
    });
  }
};


export const inviteGuard = async (req, res) => {
  try {
    const { name, mobile } = req.body;

    if (!name || !mobile) {
      return res.status(400).json({
        message: "Name and mobile are required"
      });
    }

    // 🔐 admin from token
    const admin = await User.findById(req.user.userId);

    if (!admin || !admin.societyId) {
      return res.status(403).json({
        message: "Admin society not found"
      });
    }

    // ❌ already admin or resident
    const existingUser = await User.findOne({ mobile });

    if (existingUser?.roles.includes("ADMIN")) {
      return res.status(400).json({
        message: "This number belongs to an admin"
      });
    }

    if (existingUser?.roles.includes("RESIDENT")) {
      return res.status(400).json({
        message: "This number belongs to a resident"
      });
    }

    const expiresAt = new Date(
      Date.now() + INVITE_EXPIRY_HOURS * 60 * 60 * 1000
    );

    // 🔍 check existing invite
    let invite = await Invite.findOne({
      mobile,
      role: "GUARD",
      societyId: admin.societyId
    });

    if (invite && invite.status === "USED") {
      return res.status(409).json({
        message: "Guard already onboarded"
      });
    }

    if (invite) {
      invite.name = name;
      invite.status = "PENDING";
      invite.expiresAt = expiresAt;
      invite.invitedBy = admin._id;
      await invite.save();
    } else {
      invite = await Invite.create({
        name,
        mobile,
        role: "GUARD",
        societyId: admin.societyId,
        invitedBy: admin._id,
        expiresAt
      });
    }

    // ✅ AUDIT LOG
    await auditLogger({
      req,
      action: "INVITE_GUARD",
      targetType: "INVITE",
      targetId: invite._id,
      societyId: admin.societyId,
      description: `Guard invited: ${name} (${mobile})`
    });

    res.json({
      message: "Guard invite sent successfully",
      invite
    });
  } catch (err) {
    console.error("INVITE GUARD ERROR:", err);
    res.status(500).json({
      message: "Failed to invite guard"
    });
  }
};
